﻿using System;

namespace KorlevelGenerator.source
{
    public record Letter
    {
        public Letter(string Sender, string Recipant, DateTime Date, string Content)
        {
            this.Sender = Sender;
            this.Recipant = Recipant;
            this.Date = Date;
            this.Content = Content;
        }

        public string Sender { get; set; }
        public string Recipant { get; set; }
        public DateTime Date { get; set; }
        public string Content { get; set; }
    }
}