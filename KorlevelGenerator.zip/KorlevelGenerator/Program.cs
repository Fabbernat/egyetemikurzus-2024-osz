﻿// See https://aka.ms/new-console-template for more information
using static KorlevelGenerator.source.LetterGenerator;
using static KorlevelGenerator.source.DataGenerator;
using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics.Metrics;

namespace KorlevelGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"*Random dátum, {GetBeginDate()}.01.01. - {GetEndDate()}.12.28.*:");
            Console.WriteLine(GenerateRandomDate());
            Console.WriteLine();
            Console.WriteLine($"*Random összeg, {GetMinimum()} - {GetMaximum()}*:");
            Console.WriteLine(GenerateRandomAmount());
            Console.WriteLine();
            Console.WriteLine("*Random referencia*:");
            Console.WriteLine(GenerateRandomReference());

            try
            {
              
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt: {ex.Message}");
            }

        }
    }
}